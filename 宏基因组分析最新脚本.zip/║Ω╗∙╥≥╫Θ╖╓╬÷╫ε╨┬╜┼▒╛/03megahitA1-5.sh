#!/bin/sh
#SBATCH --job-name=megahitA1-5
#SBATCH -N 1
#SBATCH --ntasks-per-node=36
#SBATCH --partition=debug
#SBATCH --output=/public/home/wangxp/ABC-raw.data/data/11dannegahit/error/megahitA1-5.output
#SBATCH --error=/public/home/wangxp/ABC-raw.data/data/11dannegahit/error/megahitA1-5.error

cd /public/home/wangxp/ABC-raw.data/data/07bowtie/repair-fastq-host-free

/public/software/apps/biology/MEGAHIT-1.2.9/bin/megahit -1 ./A1.fq.1.gz -2 ./A1.fq.2.gz --min-contig-len 200 -o /public/home/wangxp/ABC-raw.data/data/11dannegahit/assembly/megahitA1
/public/software/apps/biology/MEGAHIT-1.2.9/bin/megahit -1 ./A2.fq.1.gz -2 ./A2.fq.2.gz --min-contig-len 200 -o /public/home/wangxp/ABC-raw.data/data/11dannegahit/assembly/megahitA2
/public/software/apps/biology/MEGAHIT-1.2.9/bin/megahit -1 ./A3.fq.1.gz -2 ./A3.fq.2.gz --min-contig-len 200 -o /public/home/wangxp/ABC-raw.data/data/11dannegahit/assembly/megahitA3
/public/software/apps/biology/MEGAHIT-1.2.9/bin/megahit -1 ./A4.fq.1.gz -2 ./A4.fq.2.gz --min-contig-len 200 -o /public/home/wangxp/ABC-raw.data/data/11dannegahit/assembly/megahitA4
/public/software/apps/biology/MEGAHIT-1.2.9/bin/megahit -1 ./A5.fq.1.gz -2 ./A5.fq.2.gz --min-contig-len 200 -o /public/home/wangxp/ABC-raw.data/data/11dannegahit/assembly/megahitA5