#!/bin/sh
#SBATCH --job-name=fastp-A1
#SBATCH -N 1
#SBATCH --ntasks-per-node=4
#SBATCH --partition=debug
#SBATCH --output=/public/home/wangxp/ABC-raw.data/data/04fastp/error/output-fastp33.A1
#SBATCH --error=/public/home/wangxp/ABC-raw.data/data/04fastp/error/error-fastp33.A1


cd /public/home/wangxp/ABC-raw.data/33-cat-ABA

/public/software/apps/biology/fastp/fastp --in1 A1_1P.fq.gz --in2 A1_2P.fq.gz --out1 ./A1_paried_R1_new.fastq.gz --out2 ./A1_paried_R2_new.fastq.gz -j ./A1A_new.json -h ./A1_fastp_new.html -W 4 -M 20 -n 0 -q 20 -5 5 -3 5 -l 50

