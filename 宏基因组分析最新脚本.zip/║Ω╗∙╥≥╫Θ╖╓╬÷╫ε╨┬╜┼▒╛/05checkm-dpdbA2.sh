#!/bin/bash
#SBATCH --job-name=checkm-dpdbA2
#SBATCH -N 1
#SBATCH --ntasks-per-node=36
#SBATCH --partition=bio
#SBATCH --output=/public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/error/checkm-dpdbA2.out
#SBATCH --error=/public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/error/checkm-dpdbA2.err

source activate checkm
conda activate checkm
cd /public/home/wangxp/ABC-raw.data/data

checkm lineage_wf ./12metawrap/danmetawrap/binA2/metabat2_bins ./12metawrap/danmetawrap/bin_output_dir/check-dpdbA2_output_dir -f ./12metawrap/danmetawrap/bin_quality/dpdbA2_checkM.tsv --tab_table -t 36 --pplacer_threads 36  -x fa
srun vasp_std
