#!/bin/sh
#SBATCH --job-name=bowtie-A1
#SBATCH -N 1
#SBATCH --ntasks-per-node=4
#SBATCH --partition=debug
#SBATCH --output=output-bowtie.A1
#SBATCH --error=error-bowtie.A1

cd /public/home/wangxp/ABC-raw.data/cat-ABC

/public/software/apps/biology/bowtie2-2.4.4/bowtie2 -x /public/home/wangxp/ABC-raw.data/data/07bowtie/Fuchi.build.chr.fa -1 ./A1A_1.fq.gz -2 ./A1A_2.fq.gz -p 30 -S /public/home/wangxp/ABC-raw.data/data/07bowtie/A1A.host.sam --un-conc-gz /public/home/wangxp/ABC-raw.data/data/07bowtie/repair-fastq-host-free/A1A.fq.gz  1>/public/home/wangxp/ABC-raw.data/data/07bowtie/repair-fastq-host-free/A1A.o 2>/public/home/wangxp/ABC-raw.data/data/07bowtie/repair-fastq-host-free/A1A.e
