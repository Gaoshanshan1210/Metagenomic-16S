#!/bin/sh
#SBATCH --job-name=DPDBA1-15
#SBATCH -N 1
#SBATCH --ntasks-per-node=36
#SBATCH --partition=debug
#SBATCH --output=/public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/error/DPDBA1-15.output
#SBATCH --error=/public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/error/DPDBA1-15.error

cd /public/home/wangxp/ABC-raw.data/data

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA1/A1final.contigs.fa -o ./12metawrap/danmetawrap/BinA1 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A1_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A1_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA2/A2final.contigs.fa -o ./12metawrap/danmetawrap/BinA2 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A2_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A2_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA3/A3final.contigs.fa -o ./12metawrap/danmetawrap/BinA3 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A3_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A3_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA4/A4final.contigs.fa -o ./12metawrap/danmetawrap/BinA4 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A4_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A4_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA5/A5final.contigs.fa -o ./12metawrap/danmetawrap/BinA5 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A5_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A5_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA6/A6final.contigs.fa -o ./12metawrap/danmetawrap/BinA6 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A6_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A6_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA7/A7final.contigs.fa -o ./12metawrap/danmetawrap/BinA7 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A7_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A7_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA8/A8final.contigs.fa -o ./12metawrap/danmetawrap/BinA8 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A8_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A8_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA9/A9final.contigs.fa -o ./12metawrap/danmetawrap/BinA9 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A9_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A9_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA10/A10final.contigs.fa -o ./12metawrap/danmetawrap/BinA10 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A10_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A10_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA11/A11final.contigs.fa -o ./12metawrap/danmetawrap/BinA11 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A11_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A11_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA12/A12final.contigs.fa -o ./12metawrap/danmetawrap/BinA12 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A12_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A12_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA13/A13final.contigs.fa -o ./12metawrap/danmetawrap/BinA13 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A13_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A13_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA14/A14final.contigs.fa -o ./12metawrap/danmetawrap/BinA14 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A14_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A14_hostfree_2.fastq.gz

metawrap binning --metabat2 -a ./11dannegahit/assembly/megahitA15/A15final.contigs.fa -o ./12metawrap/danmetawrap/BinA15 -l 1500 -t 36 ./07bowtie/repair-fastq-host-free/A1-15singl/A15_hostfree_1.fastq.gz ./07bowtie/repair-fastq-host-free/A1-15singl/A15_hostfree_2.fastq.gz