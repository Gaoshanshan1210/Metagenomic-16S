#!/usr/bin/bash
#SBATCH --job-name=refinme-A
#SBATCH --nodes=1
#SBATCH --cpus-per-task=36
#SBATCH --partition=normal
#SBATCH --output=/public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/error/refinme-A.o
#SBATCH --error=/public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/error/refinme-A.e

source /public/software/profile.d/apps_Anaconda3 
conda activate refinem

cd /public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/


ulimit -n 2096

less /public/home/wangxp/ABC-raw.data/data/12metawrap/danmetawrap/nameA.txt|while read line

	do

	cd ${line}

	######samtools######
        /public/home/wangxp/software/samtools_1.9/samtools-1.9/samtools index ./work_files/${line}_hostfree.bam


	######1-3###stats
	refinem scaffold_stats -c 36 -x fa ./work_files/assembly.fa  ./2checkm_bins ./6stat_output ./work_files/${line}_hostfree.bam
	refinem outliers ./6stat_output/scaffold_stats.tsv ./6stat_output/
	refinem filter_bins -x fa ./2checkm_bins  ./6stat_output/outliers.tsv ./3filter_output_bins1


	######5####taxon1
	time refinem call_genes -c 36 -x fa 3filter_output_bins1/  7gene_output
	time refinem taxon_profile -c 36 7gene_output 6stat_output/scaffold_stats.tsv /public/home/wangxp/software/refinem/gtdb_r95_protein_db.2020-07-30.dmnd /public/home/wangxp/software/refinem/gtdb_r95_taxonomy.2020-07-30.tsv 8taxon_profile_output	


	######6-7####taxon2
	time refinem taxon_filter -c 36 8taxon_profile_output 8taxon_profile_output/taxon_filter.tsv
	time refinem filter_bins -x fa 3filter_output_bins1 8taxon_profile_output/taxon_filter.tsv 4filter_output_bins2


	######8####16S
	time refinem ssu_erroneous -x fa 4filter_output_bins2  8taxon_profile_output/ /public/home/wangxp/software/refinem/gtdb_r80_ssu_db.2018-01-18.fna /public/home/wangxp/software/refinem/gtdb_r80_taxonomy.2017-12-15.tsv 5ssu_output	
	refinem filter_bins -x fa 4filter_output_bins2 5ssu_output/ssu_erroneous.tsv 9ssu_output_bins
		
        cd ../
	
done



